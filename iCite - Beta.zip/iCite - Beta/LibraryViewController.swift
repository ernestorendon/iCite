//
//  FirstViewController.swift
//  iCite - Beta
//
//  Created by Ernesto on 2/18/17.
//  Copyright © 2017 ErnestoRendon. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

