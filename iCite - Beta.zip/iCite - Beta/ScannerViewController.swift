//
//  ScannerViewController.swift
//  iCite - Beta
//
//  Created by Ernesto on 2/18/17.
//  Copyright © 2017 ErnestoRendon. All rights reserved.
//

import UIKit
//import BarcodeScanner

class ScannerViewController: UIViewController {
    
    

    let ScannerViewController = BarcodeScannerController()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        ScannerViewController.codeDelegate = self
        ScannerViewController.errorDelegate = self
        ScannerViewController.dismissalDelegate = self
        present(ScannerViewController, animated: true, completion: nil)

            
        }
    
    func barcodeScanner(_ controller: BarcodeScannerController, didCaptureCode code: String, type: String){
                       controller.dismiss(animated: true, completion: nil)
    }

    @IBAction func RescanBarcode(_ sender: Any) {
        present(ScannerViewController, animated: true, completion: nil)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}

extension ScannerViewController: BarcodeScannerCodeDelegate {
    
//    func barcodeScanner(_ controller: BarcodeScannerController, didCaptureCode code: String, type: String) {
//        print(code)
//        controller.reset()
//    }
}

extension ScannerViewController: BarcodeScannerErrorDelegate {
    
    func barcodeScanner(_ controller: BarcodeScannerController, didReceiveError error: Error) {
        print(error)
    }
}

extension ScannerViewController: BarcodeScannerDismissalDelegate {
    
    func barcodeScannerDidDismiss(_ controller: BarcodeScannerController) {
        controller.dismiss(animated: true, completion: nil)
    }
}
