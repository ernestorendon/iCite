//
//  SettingsViewController.swift
//  iCite - Beta
//
//  Created by Ernesto on 2/18/17.
//  Copyright © 2017 ErnestoRendon. All rights reserved.
//

import UIKit

class SettingsViewController: UITableViewController {
    

}
